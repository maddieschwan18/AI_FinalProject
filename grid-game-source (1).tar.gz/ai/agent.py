"""
AI agent for Grid Game.

This script reads a JSON request from stdin and writes a JSON response to
stdout. The Express API server (artifacts/api-server) invokes this script
once per AI move via subprocess.

Replace the body of `get_move` with your own AI logic. Everything else
(I/O wiring, validation, error reporting) is already handled below.

Request (stdin) shape:
    {
        "rows": int,                   # 2..10
        "cols": int,                   # 2..10
        "depth": int,                  # 1..10  (1 = 2D game, >1 = 3D game)
        "w": int,                      # 1..4   (1 = 2D/3D game, >1 = 4D game)
        "board": list[str],            # length rows*cols*depth*w, each "" | "X" | "O"
        "player": "X" | "O"            # the marker the AI should place
    }

Index convention for `board`:
    idx = w * (rows * cols * depth) + z * (rows * cols) + y * cols + x
        x = column     (0..cols-1)
        y = row        (0..rows-1)
        z = layer      (0..depth-1)
        w = hyperslice (0..w-1)

Response (stdout) shape:
    {
        "row": int,                    # 0..rows-1     (y)
        "col": int,                    # 0..cols-1     (x)
        "z":   int,                    # 0..depth-1    (omit or 0 for 2D)
        "w":   int                     # 0..w-1        (omit or 0 for 2D/3D)
    }

On error, exit with a non-zero status code and write a JSON error object
to stdout: {"error": "<message>"}.
"""

from __future__ import annotations

import json
import random
import sys
from typing import List, Literal, TypedDict


CellValue = Literal["", "X", "O"]
Player = Literal["X", "O"]


class MoveRequest(TypedDict):
    rows: int
    cols: int
    depth: int
    w: int
    board: List[CellValue]
    player: Player


class Move(TypedDict, total=False):
    row: int
    col: int
    z: int
    w: int


def get_move(request: MoveRequest) -> Move:
    """
    Return the AI's next move for the given board state.

    >>> REPLACE THIS FUNCTION WITH YOUR PYTHON AI LOGIC. <<<

    The default implementation just picks a random empty cell, so the
    frontend has something to talk to until you wire in the real agent.
    Works for 2D (depth==1, w==1), 3D (depth>1, w==1), and 4D (w>1) boards.
    """
    rows = request["rows"]
    cols = request["cols"]
    depth = request["depth"]
    board = request["board"]
    layer_size = rows * cols
    hyperslice_size = layer_size * depth

    empty_indices = [i for i, cell in enumerate(board) if cell == ""]
    if not empty_indices:
        raise ValueError("No empty cells remain on the board.")

    choice = random.choice(empty_indices)
    w = choice // hyperslice_size
    rem_w = choice % hyperslice_size
    z = rem_w // layer_size
    rem_z = rem_w % layer_size
    return {"row": rem_z // cols, "col": rem_z % cols, "z": z, "w": w}


# ---------------------------------------------------------------------------
# I/O wiring — you generally do not need to edit anything below this line.
# ---------------------------------------------------------------------------


def _validate(request: object) -> MoveRequest:
    if not isinstance(request, dict):
        raise ValueError("Request must be a JSON object.")

    rows = request.get("rows")
    cols = request.get("cols")
    depth = request.get("depth", 1)
    w = request.get("w", 1)
    board = request.get("board")
    player = request.get("player")

    if not isinstance(rows, int) or not (2 <= rows <= 10):
        raise ValueError("`rows` must be an integer in [2, 10].")
    if not isinstance(cols, int) or not (2 <= cols <= 10):
        raise ValueError("`cols` must be an integer in [2, 10].")
    if not isinstance(depth, int) or not (1 <= depth <= 10):
        raise ValueError("`depth` must be an integer in [1, 10].")
    if not isinstance(w, int) or not (1 <= w <= 4):
        raise ValueError("`w` must be an integer in [1, 4].")
    expected_len = rows * cols * depth * w
    if not isinstance(board, list) or len(board) != expected_len:
        raise ValueError(
            f"`board` must be a list of length rows*cols*depth*w ({expected_len})."
        )
    for cell in board:
        if cell not in ("", "X", "O"):
            raise ValueError("Each board cell must be '', 'X', or 'O'.")
    if player not in ("X", "O"):
        raise ValueError("`player` must be 'X' or 'O'.")

    return {
        "rows": rows,
        "cols": cols,
        "depth": depth,
        "w": w,
        "board": board,
        "player": player,
    }


def main() -> int:
    try:
        raw = sys.stdin.read()
        if not raw.strip():
            raise ValueError("No input received on stdin.")
        request = _validate(json.loads(raw))
        move = get_move(request)

        z = move.get("z", 0)
        w = move.get("w", 0)
        row = move.get("row")
        col = move.get("col")

        if (
            not isinstance(row, int)
            or not isinstance(col, int)
            or not isinstance(z, int)
            or not isinstance(w, int)
        ):
            raise ValueError("AI must return integer `row`, `col`, `z`, and `w`.")
        if not (0 <= row < request["rows"]):
            raise ValueError(f"`row` {row} out of bounds for {request['rows']} rows.")
        if not (0 <= col < request["cols"]):
            raise ValueError(f"`col` {col} out of bounds for {request['cols']} cols.")
        if not (0 <= z < request["depth"]):
            raise ValueError(f"`z` {z} out of bounds for depth {request['depth']}.")
        if not (0 <= w < request["w"]):
            raise ValueError(f"`w` {w} out of bounds for size {request['w']}.")

        rows = request["rows"]
        cols = request["cols"]
        depth = request["depth"]
        idx = w * (rows * cols * depth) + z * (rows * cols) + row * cols + col
        if request["board"][idx] != "":
            raise ValueError(
                f"AI tried to play on occupied cell (row={row}, col={col}, z={z}, w={w})."
            )

        sys.stdout.write(json.dumps({"row": row, "col": col, "z": z, "w": w}))
        return 0
    except Exception as exc:  # noqa: BLE001
        sys.stdout.write(json.dumps({"error": str(exc)}))
        return 1


if __name__ == "__main__":
    sys.exit(main())
