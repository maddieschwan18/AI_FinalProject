"""
AI agent for Grid Game.

This script reads a JSON request from stdin and writes a JSON response to
stdout. The Express API server (artifacts/api-server) invokes this script
once per AI move via subprocess.

Replace the body of `get_move` with your own AI logic. Everything else
(I/O wiring, validation, error reporting) is already handled below.

Request (stdin) shape:
    {
        "rows": int,                   # 2..10
        "cols": int,                   # 2..10
        "board": list[str],            # length rows*cols, each "" | "X" | "O"
        "player": "X" | "O"            # the marker the AI should place
    }

Response (stdout) shape:
    {
        "row": int,                    # 0..rows-1
        "col": int                     # 0..cols-1
    }

On error, exit with a non-zero status code and write a JSON error object
to stdout: {"error": "<message>"}.
"""

from __future__ import annotations

import json
import random
import sys
from typing import List, Literal, TypedDict


CellValue = Literal["", "X", "O"]
Player = Literal["X", "O"]


class MoveRequest(TypedDict):
    rows: int
    cols: int
    board: List[CellValue]
    player: Player


class Move(TypedDict):
    row: int
    col: int


def get_move(request: MoveRequest) -> Move:
    """
    Return the AI's next move for the given board state.

    >>> REPLACE THIS FUNCTION WITH YOUR PYTHON AI LOGIC. <<<

    The default implementation just picks a random empty cell, so the
    frontend has something to talk to until you wire in the real agent.
    """
    rows = request["rows"]
    cols = request["cols"]
    board = request["board"]

    empty_indices = [i for i, cell in enumerate(board) if cell == ""]
    if not empty_indices:
        raise ValueError("No empty cells remain on the board.")

    choice = random.choice(empty_indices)
    return {"row": choice // cols, "col": choice % cols}


# ---------------------------------------------------------------------------
# I/O wiring — you generally do not need to edit anything below this line.
# ---------------------------------------------------------------------------


def _validate(request: object) -> MoveRequest:
    if not isinstance(request, dict):
        raise ValueError("Request must be a JSON object.")

    rows = request.get("rows")
    cols = request.get("cols")
    board = request.get("board")
    player = request.get("player")

    if not isinstance(rows, int) or not (2 <= rows <= 10):
        raise ValueError("`rows` must be an integer in [2, 10].")
    if not isinstance(cols, int) or not (2 <= cols <= 10):
        raise ValueError("`cols` must be an integer in [2, 10].")
    if not isinstance(board, list) or len(board) != rows * cols:
        raise ValueError("`board` must be a list of length rows*cols.")
    for cell in board:
        if cell not in ("", "X", "O"):
            raise ValueError("Each board cell must be '', 'X', or 'O'.")
    if player not in ("X", "O"):
        raise ValueError("`player` must be 'X' or 'O'.")

    return {"rows": rows, "cols": cols, "board": board, "player": player}


def main() -> int:
    try:
        raw = sys.stdin.read()
        if not raw.strip():
            raise ValueError("No input received on stdin.")
        request = _validate(json.loads(raw))
        move = get_move(request)

        if not (0 <= move["row"] < request["rows"]) or not (
            0 <= move["col"] < request["cols"]
        ):
            raise ValueError(
                f"AI returned out-of-bounds move {move} for "
                f"{request['rows']}x{request['cols']} board."
            )
        idx = move["row"] * request["cols"] + move["col"]
        if request["board"][idx] != "":
            raise ValueError(
                f"AI tried to play on occupied cell ({move['row']}, {move['col']})."
            )

        sys.stdout.write(json.dumps(move))
        return 0
    except Exception as exc:  # noqa: BLE001
        sys.stdout.write(json.dumps({"error": str(exc)}))
        return 1


if __name__ == "__main__":
    sys.exit(main())
