# Workspace

## Overview

pnpm workspace monorepo using TypeScript. Each package manages its own dependencies.

## Stack

- **Monorepo tool**: pnpm workspaces
- **Node.js version**: 24
- **Package manager**: pnpm
- **TypeScript version**: 5.9
- **API framework**: Express 5
- **Database**: PostgreSQL + Drizzle ORM
- **Validation**: Zod (`zod/v4`), `drizzle-zod`
- **API codegen**: Orval (from OpenAPI spec)
- **Build**: esbuild (CJS bundle)

## Key Commands

- `pnpm run typecheck` — full typecheck across all packages
- `pnpm run build` — typecheck + build all packages
- `pnpm --filter @workspace/api-spec run codegen` — regenerate API hooks and Zod schemas from OpenAPI spec
- `pnpm --filter @workspace/db run push` — push DB schema changes (dev only)
- `pnpm --filter @workspace/api-server run dev` — run API server locally

## Artifacts

- **grid-game** (`artifacts/grid-game`) — React + Vite frontend at `/`. A configurable grid (rows and columns independently from 2 to 10) with click-to-place X/O cells. Includes a "Play vs AI" mode that posts the board state to the Express API server (`POST /api/ai/move`), which spawns `ai/agent.py` via subprocess to compute the next move.

## Python AI agent

- `ai/agent.py` — entry point for the Python AI agent. Reads the request as JSON on stdin, writes a `{ "row", "col" }` JSON response on stdout. The default implementation picks a random empty cell. Replace the body of `get_move(request)` with your own logic; the surrounding I/O wiring, validation, and error reporting are already in place.
- `artifacts/api-server/src/routes/ai.ts` — Express route that spawns Python (`python3` by default; override via `PYTHON_BIN` env var), with a 10s timeout and validation against the OpenAPI-generated Zod schemas.

See the `pnpm-workspace` skill for workspace structure, TypeScript setup, and package details.
