import { useEffect, useMemo, useState, useCallback, useRef } from "react";
import { Button } from "@/components/ui/button";
import { Slider } from "@/components/ui/slider";
import { Label } from "@/components/ui/label";
import { Card } from "@/components/ui/card";
import { Switch } from "@/components/ui/switch";
import {
  RotateCcw,
  Grid3x3,
  Bot,
  AlertCircle,
  Loader2,
  Trophy,
  Eraser,
} from "lucide-react";
import { useGetAiMove } from "@workspace/api-client-react";

type CellValue = "" | "X" | "O";
type Player = "X" | "O";

const MIN_SIZE = 2;
const MAX_SIZE = 10;
const MIN_WIN_LEN = 2;

function makeEmptyBoard(rows: number, cols: number): CellValue[] {
  return Array<CellValue>(rows * cols).fill("");
}

function findWinningLine(
  board: CellValue[],
  rows: number,
  cols: number,
  winLen: number,
): { player: Player; cells: number[] } | null {
  const directions: Array<[number, number]> = [
    [0, 1], // horizontal
    [1, 0], // vertical
    [1, 1], // diagonal down-right
    [1, -1], // diagonal down-left
  ];
  for (let r = 0; r < rows; r++) {
    for (let c = 0; c < cols; c++) {
      const start = board[r * cols + c];
      if (start !== "X" && start !== "O") continue;
      for (const [dr, dc] of directions) {
        const endR = r + dr * (winLen - 1);
        const endC = c + dc * (winLen - 1);
        if (endR < 0 || endR >= rows || endC < 0 || endC >= cols) continue;
        const cells: number[] = [];
        let ok = true;
        for (let k = 0; k < winLen; k++) {
          const idx = (r + dr * k) * cols + (c + dc * k);
          if (board[idx] !== start) {
            ok = false;
            break;
          }
          cells.push(idx);
        }
        if (ok) return { player: start, cells };
      }
    }
  }
  return null;
}

export default function GridPage() {
  const [rows, setRows] = useState<number>(3);
  const [cols, setCols] = useState<number>(3);
  const [winLen, setWinLen] = useState<number>(3);
  const [board, setBoard] = useState<CellValue[]>(() => makeEmptyBoard(3, 3));
  const [currentPlayer, setCurrentPlayer] = useState<Player>("X");
  const [moveCount, setMoveCount] = useState<number>(0);

  const [vsAi, setVsAi] = useState<boolean>(false);
  const [humanPlayer, setHumanPlayer] = useState<Player>("X");
  const [aiError, setAiError] = useState<string | null>(null);

  const [scores, setScores] = useState<{ X: number; O: number; draws: number }>(
    { X: 0, O: 0, draws: 0 },
  );
  const scoredGameRef = useRef<number>(0);

  const aiMutation = useGetAiMove();
  const aiMutate = aiMutation.mutate;
  const isAiThinking = aiMutation.isPending;
  const requestedRef = useRef<number>(0);

  const aiPlayer: Player = humanPlayer === "X" ? "O" : "X";
  const noEmptyCells = useMemo(() => board.every((c) => c !== ""), [board]);
  const maxWinLen = Math.max(rows, cols);
  const effectiveWinLen = Math.min(winLen, maxWinLen);

  const winner = useMemo(
    () => findWinningLine(board, rows, cols, effectiveWinLen),
    [board, rows, cols, effectiveWinLen],
  );
  const isGameOver = winner !== null || noEmptyCells;

  const resetState = useCallback(
    (nextRows: number, nextCols: number, opts?: { resetScores?: boolean }) => {
      setBoard(makeEmptyBoard(nextRows, nextCols));
      setCurrentPlayer("X");
      setMoveCount(0);
      setAiError(null);
      requestedRef.current += 1;
      scoredGameRef.current += 1;
      if (opts?.resetScores) {
        setScores({ X: 0, O: 0, draws: 0 });
      }
    },
    [],
  );

  const handleResetScores = useCallback(() => {
    setScores({ X: 0, O: 0, draws: 0 });
  }, []);

  // Tally a finished game exactly once.
  useEffect(() => {
    if (!isGameOver) return;
    const gameId = scoredGameRef.current;
    if (gameId < 0) return;
    scoredGameRef.current = -1;
    setScores((prev) => {
      if (winner) {
        return { ...prev, [winner.player]: prev[winner.player] + 1 };
      }
      return { ...prev, draws: prev.draws + 1 };
    });
  }, [isGameOver, winner]);

  const handleRowsChange = useCallback(
    (value: number[]) => {
      const next = value[0] ?? MIN_SIZE;
      setRows(next);
      resetState(next, cols, { resetScores: true });
    },
    [cols, resetState],
  );

  const handleColsChange = useCallback(
    (value: number[]) => {
      const next = value[0] ?? MIN_SIZE;
      setCols(next);
      resetState(rows, next, { resetScores: true });
    },
    [rows, resetState],
  );

  const handleCellClick = useCallback(
    (index: number) => {
      if (isGameOver) return;
      if (board[index] !== "") return;
      if (vsAi && currentPlayer !== humanPlayer) return;
      if (isAiThinking) return;

      setBoard((prev) => {
        const next = [...prev];
        next[index] = currentPlayer;
        return next;
      });
      setCurrentPlayer((p) => (p === "X" ? "O" : "X"));
      setMoveCount((c) => c + 1);
      setAiError(null);
    },
    [board, currentPlayer, vsAi, humanPlayer, isAiThinking, isGameOver],
  );

  const handleReset = useCallback(() => {
    resetState(rows, cols);
  }, [rows, cols, resetState]);

  const handleToggleVsAi = useCallback(
    (next: boolean) => {
      setVsAi(next);
      resetState(rows, cols, { resetScores: true });
    },
    [rows, cols, resetState],
  );

  const handleSwapSides = useCallback(() => {
    setHumanPlayer((p) => (p === "X" ? "O" : "X"));
    resetState(rows, cols, { resetScores: true });
  }, [rows, cols, resetState]);

  // When it's the AI's turn, ask the backend for its move.
  useEffect(() => {
    if (!vsAi) return;
    if (isGameOver) return;
    if (currentPlayer === humanPlayer) return;
    if (isAiThinking) return;

    const requestId = requestedRef.current;
    const snapshotBoard = board;
    const snapshotRows = rows;
    const snapshotCols = cols;

    aiMutate(
      {
        data: {
          rows: snapshotRows,
          cols: snapshotCols,
          board: snapshotBoard,
          player: aiPlayer,
        },
      },
      {
        onSuccess: (move) => {
          if (requestId !== requestedRef.current) return;
          const idx = move.row * snapshotCols + move.col;
          if (snapshotBoard[idx] !== "") {
            setAiError(
              `AI returned an occupied cell (${move.row}, ${move.col}).`,
            );
            return;
          }
          setBoard((prev) => {
            const next = [...prev];
            next[idx] = aiPlayer;
            return next;
          });
          setCurrentPlayer(humanPlayer);
          setMoveCount((c) => c + 1);
          setAiError(null);
        },
        onError: (err) => {
          if (requestId !== requestedRef.current) return;
          const message =
            err && typeof err === "object" && "data" in err
              ? ((err as { data?: { error?: string } }).data?.error ?? null)
              : null;
          setAiError(message ?? (err instanceof Error ? err.message : "AI request failed."));
        },
      },
    );
  }, [
    vsAi,
    isGameOver,
    currentPlayer,
    humanPlayer,
    isAiThinking,
    board,
    rows,
    cols,
    aiPlayer,
    aiMutate,
  ]);

  const cellSizePx = useMemo(() => {
    const longest = Math.max(rows, cols);
    const target = Math.min(560, Math.max(280, 80 * longest));
    return Math.floor(target / longest);
  }, [rows, cols]);

  const boardWidth = cellSizePx * cols + (cols - 1) * 6;

  const turnLabel = isGameOver
    ? winner
      ? "Winner"
      : "Result"
    : vsAi
      ? currentPlayer === humanPlayer
        ? "Your turn"
        : isAiThinking
          ? "AI thinking…"
          : "AI's turn"
      : "Next";

  const turnValueText = isGameOver
    ? winner
      ? winner.player
      : "Draw"
    : currentPlayer;

  const winningCellSet = useMemo(
    () => new Set(winner?.cells ?? []),
    [winner],
  );

  const winnerBannerText = winner
    ? vsAi
      ? winner.player === humanPlayer
        ? `You win! (${winner.player})`
        : `AI wins (${winner.player})`
      : `${winner.player} wins!`
    : noEmptyCells
      ? "It's a draw."
      : null;

  return (
    <div className="min-h-screen w-full bg-background text-foreground">
      <div className="mx-auto max-w-5xl px-6 py-10">
        <header className="mb-8 flex items-center gap-3">
          <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-primary text-primary-foreground">
            <Grid3x3 className="h-5 w-5" />
          </div>
          <div>
            <h1 className="text-2xl font-semibold tracking-tight">Grid Game</h1>
            <p className="text-sm text-muted-foreground">
              Generate any grid from {MIN_SIZE}×{MIN_SIZE} to {MAX_SIZE}×{MAX_SIZE}
            </p>
          </div>
        </header>

        <div className="grid gap-6 md:grid-cols-[300px_1fr]">
          <Card className="h-fit p-5">
            <div className="space-y-6">
              <div className="space-y-3">
                <div className="flex items-baseline justify-between">
                  <Label htmlFor="rows-slider" className="text-sm font-medium">
                    Rows
                  </Label>
                  <span className="font-mono text-sm tabular-nums text-muted-foreground">
                    {rows}
                  </span>
                </div>
                <Slider
                  id="rows-slider"
                  min={MIN_SIZE}
                  max={MAX_SIZE}
                  step={1}
                  value={[rows]}
                  onValueChange={handleRowsChange}
                  data-testid="slider-rows"
                />
                <div className="flex justify-between text-xs text-muted-foreground">
                  <span>{MIN_SIZE}</span>
                  <span>{MAX_SIZE}</span>
                </div>
              </div>

              <div className="space-y-3">
                <div className="flex items-baseline justify-between">
                  <Label htmlFor="cols-slider" className="text-sm font-medium">
                    Columns
                  </Label>
                  <span className="font-mono text-sm tabular-nums text-muted-foreground">
                    {cols}
                  </span>
                </div>
                <Slider
                  id="cols-slider"
                  min={MIN_SIZE}
                  max={MAX_SIZE}
                  step={1}
                  value={[cols]}
                  onValueChange={handleColsChange}
                  data-testid="slider-cols"
                />
                <div className="flex justify-between text-xs text-muted-foreground">
                  <span>{MIN_SIZE}</span>
                  <span>{MAX_SIZE}</span>
                </div>
              </div>

              <div className="space-y-3">
                <div className="flex items-baseline justify-between">
                  <Label htmlFor="win-slider" className="text-sm font-medium">
                    In a row to win
                  </Label>
                  <span className="font-mono text-sm tabular-nums text-muted-foreground">
                    {effectiveWinLen}
                  </span>
                </div>
                <Slider
                  id="win-slider"
                  min={MIN_WIN_LEN}
                  max={maxWinLen}
                  step={1}
                  value={[effectiveWinLen]}
                  onValueChange={(value) => {
                    const next = value[0] ?? MIN_WIN_LEN;
                    setWinLen(next);
                    resetState(rows, cols, { resetScores: true });
                  }}
                  disabled={maxWinLen <= MIN_WIN_LEN}
                  data-testid="slider-win-length"
                />
                <div className="flex justify-between text-xs text-muted-foreground">
                  <span>{MIN_WIN_LEN}</span>
                  <span>{maxWinLen}</span>
                </div>
              </div>

              <div className="space-y-3 rounded-md border border-border bg-muted/40 p-3">
                <div className="flex items-center justify-between gap-3">
                  <div className="flex items-center gap-2">
                    <Bot className="h-4 w-4 text-muted-foreground" />
                    <Label htmlFor="vs-ai-switch" className="text-sm font-medium">
                      Play vs AI
                    </Label>
                  </div>
                  <Switch
                    id="vs-ai-switch"
                    checked={vsAi}
                    onCheckedChange={handleToggleVsAi}
                    data-testid="switch-vs-ai"
                  />
                </div>
                {vsAi && (
                  <div className="flex items-center justify-between text-sm">
                    <span className="text-muted-foreground">You play as</span>
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={handleSwapSides}
                      data-testid="button-swap-sides"
                      className="font-mono"
                    >
                      {humanPlayer}
                      <span className="mx-1.5 text-muted-foreground">vs</span>
                      <span className="text-muted-foreground">{aiPlayer}</span>
                    </Button>
                  </div>
                )}
              </div>

              <div className="space-y-3 rounded-md border border-border bg-muted/40 p-3">
                <div className="flex items-center justify-between text-sm">
                  <span className="text-muted-foreground">Size</span>
                  <span className="font-mono tabular-nums">
                    {rows} × {cols}
                  </span>
                </div>
                <div className="flex items-center justify-between text-sm">
                  <span className="text-muted-foreground">Win at</span>
                  <span className="font-mono tabular-nums">
                    {effectiveWinLen} in a row
                  </span>
                </div>
                <div className="flex items-center justify-between text-sm">
                  <span className="text-muted-foreground">Moves</span>
                  <span className="font-mono tabular-nums">{moveCount}</span>
                </div>
                <div className="flex items-center justify-between text-sm">
                  <span className="text-muted-foreground">{turnLabel}</span>
                  <span
                    className={[
                      "flex items-center gap-1.5 font-mono font-semibold",
                      isGameOver && !winner
                        ? "text-muted-foreground"
                        : turnValueText === "X"
                          ? "text-primary"
                          : turnValueText === "O"
                            ? "text-accent"
                            : "text-muted-foreground",
                    ].join(" ")}
                    data-testid="text-current-player"
                  >
                    {!isGameOver &&
                      isAiThinking &&
                      currentPlayer !== humanPlayer &&
                      vsAi && <Loader2 className="h-3 w-3 animate-spin" />}
                    {turnValueText}
                  </span>
                </div>
              </div>

              {winnerBannerText && (
                <div
                  className="flex items-center gap-2 rounded-md border border-primary/30 bg-primary/10 p-3 text-sm font-medium text-primary"
                  data-testid="text-winner-banner"
                >
                  <Trophy className="h-4 w-4 shrink-0" />
                  <span>{winnerBannerText}</span>
                </div>
              )}

              {aiError && (
                <div
                  className="flex items-start gap-2 rounded-md border border-destructive/30 bg-destructive/10 p-3 text-xs text-destructive"
                  data-testid="text-ai-error"
                >
                  <AlertCircle className="mt-0.5 h-4 w-4 shrink-0" />
                  <span>{aiError}</span>
                </div>
              )}

              <div className="space-y-2 rounded-md border border-border bg-muted/40 p-3">
                <div className="flex items-center justify-between text-xs uppercase tracking-wide text-muted-foreground">
                  <span>Scoreboard</span>
                  <span className="font-mono normal-case tracking-normal">
                    {scores.X + scores.O + scores.draws} games
                  </span>
                </div>
                <div className="grid grid-cols-3 gap-2 text-center">
                  <div
                    className="rounded-md border border-border bg-background p-2"
                    data-testid="score-x"
                  >
                    <div className="font-mono text-xs text-primary">
                      {vsAi
                        ? humanPlayer === "X"
                          ? "You (X)"
                          : "AI (X)"
                        : "X"}
                    </div>
                    <div className="font-mono text-lg font-semibold tabular-nums text-primary">
                      {scores.X}
                    </div>
                  </div>
                  <div
                    className="rounded-md border border-border bg-background p-2"
                    data-testid="score-draws"
                  >
                    <div className="font-mono text-xs text-muted-foreground">
                      Draws
                    </div>
                    <div className="font-mono text-lg font-semibold tabular-nums text-muted-foreground">
                      {scores.draws}
                    </div>
                  </div>
                  <div
                    className="rounded-md border border-border bg-background p-2"
                    data-testid="score-o"
                  >
                    <div className="font-mono text-xs text-accent">
                      {vsAi
                        ? humanPlayer === "O"
                          ? "You (O)"
                          : "AI (O)"
                        : "O"}
                    </div>
                    <div className="font-mono text-lg font-semibold tabular-nums text-accent">
                      {scores.O}
                    </div>
                  </div>
                </div>
                <Button
                  variant="ghost"
                  size="sm"
                  className="w-full text-xs text-muted-foreground"
                  onClick={handleResetScores}
                  disabled={
                    scores.X === 0 && scores.O === 0 && scores.draws === 0
                  }
                  data-testid="button-reset-scores"
                >
                  <Eraser className="mr-1.5 h-3.5 w-3.5" />
                  Reset scores
                </Button>
              </div>

              <Button
                variant="secondary"
                className="w-full"
                onClick={handleReset}
                data-testid="button-reset"
              >
                <RotateCcw className="mr-2 h-4 w-4" />
                {isGameOver ? "New game" : "Reset board"}
              </Button>
            </div>
          </Card>

          <Card className="flex items-center justify-center p-6">
            <div
              className="grid gap-1.5"
              style={{
                gridTemplateColumns: `repeat(${cols}, ${cellSizePx}px)`,
                gridTemplateRows: `repeat(${rows}, ${cellSizePx}px)`,
                width: boardWidth,
              }}
              data-testid="grid-board"
            >
              {board.map((cell, i) => {
                const row = Math.floor(i / cols);
                const col = i % cols;
                const isEmpty = cell === "";
                const humanCanClick =
                  !vsAi || (currentPlayer === humanPlayer && !isAiThinking);
                const interactive = isEmpty && humanCanClick && !isGameOver;
                const isWinningCell = winningCellSet.has(i);
                return (
                  <button
                    key={i}
                    type="button"
                    onClick={() => handleCellClick(i)}
                    disabled={!interactive}
                    aria-label={`Cell row ${row + 1}, column ${col + 1}${
                      isEmpty ? "" : `, ${cell}`
                    }`}
                    data-testid={`cell-${row}-${col}`}
                    className={[
                      "flex items-center justify-center rounded-md border transition-colors",
                      "font-mono font-semibold",
                      isWinningCell
                        ? "border-primary bg-primary/15"
                        : "border-border bg-background",
                      interactive
                        ? "hover:bg-muted active:bg-muted/80 cursor-pointer"
                        : "cursor-default",
                      cell === "X" ? "text-primary" : "",
                      cell === "O" ? "text-accent" : "",
                    ].join(" ")}
                    style={{
                      fontSize: Math.max(14, Math.floor(cellSizePx * 0.45)),
                    }}
                  >
                    {cell}
                  </button>
                );
              })}
            </div>
          </Card>
        </div>

        <p className="mt-6 text-center text-xs text-muted-foreground">
          {vsAi
            ? "Your moves go through Python — edit ai/agent.py to swap in your own AI logic."
            : "Tap any cell to place a mark. Toggle “Play vs AI” to play against the Python agent."}
        </p>
      </div>
    </div>
  );
}
